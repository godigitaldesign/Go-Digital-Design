import About from "./about"
import Contact from "./contact"
import Hero from "./hero"
import Services from "./services"
import Projects from "./projects"

export { About, Contact, Hero, Services, Projects }
